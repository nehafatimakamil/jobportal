-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2022 at 08:55 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_ID` int(10) NOT NULL,
  `user_ID` int(10) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `feedback_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_ID` int(10) NOT NULL,
  `category_ID` int(10) NOT NULL,
  `job_title` varchar(500) NOT NULL,
  `job_designation` varchar(500) NOT NULL,
  `job_description` varchar(1000) NOT NULL,
  `required_qualification` varchar(300) NOT NULL,
  `required_skills` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_ID`, `category_ID`, `job_title`, `job_designation`, `job_description`, `required_qualification`, `required_skills`) VALUES
(1, 3, 'Production Analyst', 'Senior Analyst', 'Design scheduling and staffing models that provide the best optimization of labor costs, production volume and efficiency. Provide initial assessment of urgency and business impact on all support helpline calls and emails', 'Bachelor\'s Degree - Computer Science graduates', 'management skills'),
(2, 4, 'IT Specialist', 'Junior IT Manager', '1st /2nd Level support of internal customers for all IT related issues. Detailed tracking of each customer\'s service needs in JIRA based ticketing system.', '4 years degree in IT-related area', 'IT related skills'),
(3, 4, 'SQA Engineer', 'Senior SQA Developer', 'Working knowledge and experience of MS Office. Excellent English communication skills. Strong problem solving and research skills.\r\n', 'Bachelor\'s Degree - Computer Science or Data Science\r\n', 'SQA experience'),
(4, 4, 'Flutter Developer', 'Senior developer', 'Designing and developing applications, writing clean code, fixing bugs and following innovative trends', 'Bachelor\'s Degree - Computer Science graduates', 'Flutter related skills'),
(5, 1, 'Senior Associate', 'senior associate ', 'Use feedback and reflection to develop self awareness, personal strengths and address development areas and demonstrate critical thinking.', 'ACCA or Chartered Accountant', 'ACCA skills'),
(6, 3, 'AM Finance', 'Finance Manager', 'Preparation of accounts as per IAS and ISAs, liaison with auditors and conducting statutory compliances such as AGMs.', 'B-Qualified Chartered accountant (CA/ACCA/ICAEW)', 'ACCA skills');

-- --------------------------------------------------------

--
-- Table structure for table `jobs_category`
--

CREATE TABLE `jobs_category` (
  `category_ID` int(10) NOT NULL,
  `category_name` varchar(300) NOT NULL,
  `category_image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs_category`
--

INSERT INTO `jobs_category` (`category_ID`, `category_name`, `category_image`) VALUES
(1, 'Marketing', 'images/job-cat-1.png'),
(2, 'Human Resource', 'images/job2-new.png'),
(3, 'Management', 'images/job-cat-3.png'),
(4, 'Information Technology', 'images/job-cat-4-new.png');

-- --------------------------------------------------------

--
-- Table structure for table `job_status`
--

CREATE TABLE `job_status` (
  `job_ID` int(10) NOT NULL,
  `jobseeker_ID` int(10) NOT NULL,
  `job_status` varchar(50) NOT NULL,
  `call_description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registered_users`
--

CREATE TABLE `registered_users` (
  `user_ID` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_number` varchar(30) NOT NULL,
  `password` varchar(300) NOT NULL,
  `confirm_password` varchar(300) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_information`
--

CREATE TABLE `user_information` (
  `jobseeker_ID` int(10) NOT NULL,
  `user_ID` int(10) NOT NULL,
  `job_ID` int(10) NOT NULL,
  `name` varchar(300) NOT NULL,
  `fathername` varchar(300) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `coverletter` varchar(1000) NOT NULL,
  `resume` varchar(1000) NOT NULL,
  `portfolio` varchar(1000) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_ID`),
  ADD KEY `user_ID` (`user_ID`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_ID`),
  ADD KEY `category_ID` (`category_ID`);

--
-- Indexes for table `jobs_category`
--
ALTER TABLE `jobs_category`
  ADD PRIMARY KEY (`category_ID`);

--
-- Indexes for table `job_status`
--
ALTER TABLE `job_status`
  ADD KEY `jobseeker_ID` (`jobseeker_ID`),
  ADD KEY `job_ID` (`job_ID`);

--
-- Indexes for table `registered_users`
--
ALTER TABLE `registered_users`
  ADD PRIMARY KEY (`user_ID`);

--
-- Indexes for table `user_information`
--
ALTER TABLE `user_information`
  ADD PRIMARY KEY (`jobseeker_ID`),
  ADD KEY `userID` (`user_ID`),
  ADD KEY `jobID` (`job_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jobs_category`
--
ALTER TABLE `jobs_category`
  MODIFY `category_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registered_users`
--
ALTER TABLE `registered_users`
  MODIFY `user_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_information`
--
ALTER TABLE `user_information`
  MODIFY `jobseeker_ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `user_ID` FOREIGN KEY (`user_ID`) REFERENCES `registered_users` (`user_ID`) ON DELETE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `category_ID` FOREIGN KEY (`category_ID`) REFERENCES `jobs_category` (`category_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_status`
--
ALTER TABLE `job_status`
  ADD CONSTRAINT `job_ID` FOREIGN KEY (`job_ID`) REFERENCES `jobs` (`job_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobseeker_ID` FOREIGN KEY (`jobseeker_ID`) REFERENCES `user_information` (`jobseeker_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_information`
--
ALTER TABLE `user_information`
  ADD CONSTRAINT `jobID` FOREIGN KEY (`job_ID`) REFERENCES `jobs` (`job_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `userID` FOREIGN KEY (`user_ID`) REFERENCES `registered_users` (`user_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
