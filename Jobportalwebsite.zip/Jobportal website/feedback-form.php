<?php

   
   //Define valiables
   $username = "";
   $email = "";
   $errors = array();
   include('config.php');
   


   if(isset($_POST['feedback'])){

   	 $message = mysqli_real_escape_string($db, $_POST['message']);


   	 //check if details are filled

   	 if (empty($message)) {
   	 	array_push($errors, "Can't submit a blank response");

   	 }
    
    if (count($errors) ==0) {
    $user=$_SESSION['username'];
     $useridcheck = "SELECT user_ID FROM registered_users WHERE username ='$user' LIMIT 1";
   	 $result = mysqli_query($db,$useridcheck);
   	 $userI = mysqli_fetch_assoc($result)['user_ID'];
    $userID=intval($userI);
    
    var_dump($result);

    //$date_today = $_POST['datepicker'];$newDate = date("Y-m-d", strtotime($originalDate));

      $query = "INSERT INTO `feedback` (`user_ID`,`feedback`,`feedback_date`) VALUES ('$userID','$message',CURDATE())";
      mysqli_query($db,$query);
   

        }

   }
