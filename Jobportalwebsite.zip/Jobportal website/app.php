<?php 
session_start();
include('config.php');
include('seekerinfo.php');
if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must login first";
	header('location: login.php');
if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header('location: login.php');
	}
}?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="app.css">
    <title>Application forms</title>
</head>
<body>
 
    <section>
        
        <h1>Application form</h1>
        
        
        <div>
        <form method="POST" action="app.php" enctype="multipart/form-data" >
        <p>Name <span>*</span></p>
        <input type="text" placeholder="&nbsp; Name"  class="imp" required name="name">

        <p>Father's Name <span>*</span></p>
        <input type="text" placeholder="&nbsp; Father's Name"  class="imp" required name="fname">
       

        <p>Date Of Birth <span>*</span></p>
        <input type="date" name="DOB" id="DOB" style="width: 300px; height: 25px;">
       
        <p>Image <span>*</span></p>
            <!--<dt style="border: 1px solid grey; padding-top: 20px; padding-left: 15px; margin-bottom: 20px; border-radius: 5px;">-->
            <p> &nbsp;&nbsp;<input type="file" name="image" required id="file" ></p>
            <!--</dt>-->
    

        <p>Documents <span>*</span></p>
            <!--<dt style="border: 1px solid grey; padding-top: 20px; padding-left: 15px; margin-bottom: 20px; border-radius: 5px;">-->
            <p> Resume&nbsp;&nbsp;<input type="file" name="resume" required id="file" ></p>
            <p> Portfolio&nbsp;&nbsp;<input type="file" name="pf" required id="file" ></p>
            <p> Cover Letter&nbsp;&nbsp;<input type="file" name="cl" required id="file" ></p>
            <!--</dt>-->









            <input type="submit" value="submit" action="#" class="button" name="apply"/>

            </form>
            </div>  
            </section>
<form>
</form>

</body>
</html>