<?php

    
   include('config.php');
 
 
 
   if(isset($_POST['apply'])){
    
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $fname    = mysqli_real_escape_string($db, $_POST['fname']);
    $dob    = mysqli_real_escape_string($db, $_POST['DOB']);
    $image = $_FILES['image']['name'];
    $resume = $_FILES['resume']['name'];
    $pf = $_FILES['pf']['name'];
    $cl = $_FILES['cl']['name'];
    $username=$_SESSION['username'];
  


    // get the file extension
    $extension1 = pathinfo($resume, PATHINFO_EXTENSION);
    $extension2 = pathinfo($pf, PATHINFO_EXTENSION);
    $extension3 = pathinfo($cl, PATHINFO_EXTENSION);
    $extension4 = pathinfo($image, PATHINFO_EXTENSION);
    // the physical file on a temporary uploads directory on the server
    $file1 = $_FILES['resume']['tmp_name'];
    $file2 = $_FILES['pf']['tmp_name'];
    $file3 = $_FILES['cl']['tmp_name'];
    $file4 = $_FILES['image']['tmp_name'];
    move_uploaded_file($file4,"seeker-image/$image");
    move_uploaded_file($file3,"seeker-coverletter/$cl");
    move_uploaded_file($file1,"seeker-resume/$resume");
    move_uploaded_file($file2,"seeker-portfolio/$pf");

    $user = "SELECT * FROM registered_users WHERE username ='$username' ";
    $resultuser=mysqli_query($db,$user);
    $userid = mysqli_fetch_assoc($resultuser)['user_ID'];
    $userI=intval($userid);
    

    $sql = "INSERT INTO `user_information` (`user_ID`,`job_ID`, `name`,`fathername`,`image`,`coverletter`,`resume`,`portfolio`,`status`) VALUES ('$userI',2,'$name','$fname','$image','$cl','$resume','$pf','applied')";
    
    mysqli_query($db,$sql);
    if ($sql){

        echo "<center><h1>Your form has been submitted</h1></center>";
 
    }
    
    else{
        echo "Error: " . mysqli_error($db);
        }

   }


 ?>