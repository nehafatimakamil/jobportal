<?php 
session_start();
include('config.php');

if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must login first";
	header('location: login.php');
if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header('location: login.php');
	}
}?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Job Portal</title>
<meta charset="utf-8">
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sublime project"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
<link rel="icon" type="image/png" href="images/icons/favicon.png"/>

<link rel="stylesheet" type="text/css" href="styles/pg2.css">

</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
		<div class="header_container">
			<div class="container">
			<?php if (isset($_SESSION['succcess'])) :?> 
          		<h3>
     			<?php  
    			echo $_SESSION['success'];
    			unset($_SESSION['success']);
      			?>
          		</h3>
       			<?php endif ?>

				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo">
								<img class="header-logo" src="images/siteicon.png"/>
								<p><a href="#">JOB PORTAL</a></p>
							</div>
							<nav class="main_nav">
								<ul>
					<li>

										<a href="index.php">Home</a>
										
									</li>
									<li class="active">
						
										<a href="#">About Us</a>
	
									</li>

										<li><a href="jobs.php">Jobs</a>
	
									</li>
									<li><a href="contactus.php">Contact Us</a></li>
									<li>      
									<?php if (isset($_SESSION['username'])) :?>
    
       								<a href="index.php?logout='1'" >Logout</a>
    								<?php endif ?>
									</li>
									<li>
									<?php if (isset($_SESSION['username'])) :?>
        							<p> Welcome! <strong><?php echo $_SESSION['username'];?></strong></p>
    								<?php endif ?>
									</li>
								</ul>
							</nav>
							
							
								<div class="hamburger"><i class="fa fa-bars" aria-hidden="true"></i></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		


		<!-- Social -->
		<!-- <div class="header_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</header> -->

	<!-- Menu -->

	<div class="menu menu_mm trans_300">
		<div class="menu_container menu_mm">
			<div class="page_menu_content">
							
				<div class="page_menu_search menu_mm">
					<form action="#">
						<input type="search" required="required" class="page_menu_search_input menu_mm" placeholder="Search for products...">
					</form>
				</div>
				<ul class="page_menu_nav menu_mm">
					<li class="page_menu_item menu_mm"><a href="index.php">Home</a></li>
					<li class="page_menu_item menu_mm"><a href="#">About Us</a></li>
					<li class="page_menu_item menu_mm"><a href="#">Jobs</a></li>
					<li class="page_menu_item menu_mm"><a href="#">Contact Us<i class="fa fa-angle-down"></i></a></li>
					<li class="page_menu_item menu_mm"><a href="#">Login/Register<i class="fa fa-angle-down"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="menu_close"><i class="fa fa-times" aria-hidden="true"></i></div>

		<div class="menu_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</div>
	
	<!-- Home -->



<!-- Newsletter -->


		<div class="about-style">
		<div >
			<img src="images/bg-2.jpg"> 
	   </div>
   
	   <div class="about-text">
		   <h2> ABOUT US</h2>
		   <p> Our Job Portal is linked with a diverse group of companies that have a unified purpose to help people live 
			   more fulfilling and productive working lives and help organisations succeed.
		   It encompasses a strong international portfolio of employment and education businesses 
		   and is a market leader in online employment marketplaces, with deep and rich insights 
		   into the future of work.</p>
		   </div>
   
		</div>

		<div class="line"></div>

<!-- FAQ-->

<section class="FAQ">
	<h2>Frequently Asked Questions</h2>
	<button class="collapsible">Q1.  How is Job Portal different from other job boards?</button>
<div class="content">
  <p>A. Job Portal is different from other online job boards in many ways.
	First, you won’t find job scams, too-good-to-be-true business opportunities, ads, commission-only jobs, or junk jobs on Job Portal.
	Second, flexible jobs are the entire focus of our job board. And every flexible job we post is first vetted by a real person who spends as much as 30 minutes per job making sure it meets our rigorous criteria before we serve it up to you.
	Third, you don't have to spend hours browsing through job listings looking for keywords like "flexible" or "remote." We do all the legwork for you, so all you have to do is log in to find the best, most current, remote, part-time, freelance, and other flexible jobs available</p>
</div>

	<button class="collapsible">Q2. Are all of the jobs on Job Portal work-from-home jobs?</button>
<div class="content">
  <p>A. Although many jobs on Job Portal can be worked remotely, including from home, our definition of "flexible" also includes part-time, freelance, temporary, seasonal, and flexible schedule jobs, many of which do require the worker to report to a specific location some or all of the time..</p>
</div>


	<button class="collapsible">Q3. Will I need to download any software to use Job Portal?</button>
<div class="content">
  <p>A. No, Job Portal does not require any software, other than an Internet browser, to be purchased or downloaded onto your computer to use our service.</p>
</div>

<button class="collapsible">Q4. Does Job Portal guarantee that I’ll get hired?</button>
<div class="content">
  <p>A. Job Portal does not guarantee job placement. While we do the research on all the jobs we publish, the hiring process is all handled by the employer directly. However, Job Portal does guarantee that you’ll find only hand-screened, professional job leads with no ads, scams, or other junk on our site.</p>
</div>






</section>

<!-- FAQ collapsible Script -->



  <script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
coll[i].addEventListener("click", function() {
this.classList.toggle("active");
var content = this.nextElementSibling;
if (content.style.maxHeight){
content.style.maxHeight = null;
} else {
content.style.maxHeight = content.scrollHeight + "px";
} 
});
}
</script>




	

	<!-- Footer -->
	
	
	<footer style="background-image:url(images/footer.jpg)" class="">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="footer_content d-flex flex-lg-row flex-column align-items-center justify-content-lg-start justify-content-center">
						<div class="footer_logo"><a href="#">JOB PORTAL</a></div>
						<div class="copyright ml-auto mr-auto"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved  
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="footer_social ml-lg-auto">
							<ul>
								<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>