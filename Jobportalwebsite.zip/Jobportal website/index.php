<?php
  session_start();
  include('config.php');

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must login first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header('location: login.php');
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Job Portal</title>
<meta charset="utf-8">
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sublime project"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
<link rel="icon" type="image/png" href="images/icons/favicon.png"/>

</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
		<div class="header_container">
			<div class="container">


	
       			<?php if (isset($_SESSION['succcess'])) :?> 
          		<h3>
     			<?php  
    			echo $_SESSION['success'];
    			unset($_SESSION['success']);
      			?>
          		</h3>
       			<?php endif ?>

		
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo">
								<img class="header-logo" src="images/siteicon.png"/>
								<p><a href="#">JOB PORTAL</a></p>
							</div>
							<nav class="main_nav">
								<ul>
					<li class="active">

										<a href="index.php">Home</a>
										
									</li>
									<li>
						
										<a href="about.php">About Us</a>
	
									</li>

										<li><a href="jobs.php">Jobs</a>
	
									</li>
									<li><a href="contactus.php">Contact Us</a></li>
									<li>      
									<?php if (isset($_SESSION['username'])) :?>
    
       								<a href="index.php?logout='1'" >Logout</a>
    								<?php endif ?>
									</li>
									<li>
									<?php if (isset($_SESSION['username'])) :?>
        							<p> Welcome! <strong><?php echo $_SESSION['username'];?></strong></p>
    								<?php endif ?>
									</li>
								</ul>
							</nav>
							
							
								<div class="hamburger"><i class="fa fa-bars" aria-hidden="true"></i></div>
							</div>
						

						</div>


					</div>
				</div>
			</div>

		</div>
		
		
		</div>



		<!-- Social -->
		<!-- <div class="header_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</header> -->

	<!-- Menu -->

	<div class="menu menu_mm trans_300">
		<div class="menu_container menu_mm">
			<div class="page_menu_content">
							
				<div class="page_menu_search menu_mm">
					<form action="#">
						<input type="search" required="required" class="page_menu_search_input menu_mm" placeholder="Search for products...">
					</form>
				</div>
				<ul class="page_menu_nav menu_mm">
					<li class="page_menu_item menu_mm"><a href="index.php">Home</a></li>
					<li class="page_menu_item menu_mm"><a href="#">About Us</a></li>
					<li class="page_menu_item menu_mm"><a href="#">Jobs</a></li>
					<li class="page_menu_item menu_mm"><a href="#">Contact Us<i class="fa fa-angle-down"></i></a></li>
					<li class="page_menu_item menu_mm"><a href="#">Login/Register<i class="fa fa-angle-down"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="menu_close"><i class="fa fa-times" aria-hidden="true"></i></div>

		<div class="menu_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</div>


	
	<!-- Home -->

	<div class="home">
		<div class="home_slider_container">
  	
	
		
			
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">

			
				
				<!-- Slider Item -->
				<div class="owl-item home_slider_item">
					<div class="home_slider_background" style="background-image:url(images/job_banner_3.png)"></div>
					<div class="home_slider_content_container">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_slider_content"  data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">
	
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slider Item -->
				<div class="owl-item home_slider_item">
					<div class="home_slider_background" style="background-image:url(images/job_banner_2.jpg)"></div>
					<div class="home_slider_content_container">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_slider_content"  data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slider Item -->
				<div class="owl-item home_slider_item">
					<div class="home_slider_background" style="background-image:url(images/job_banner_1.jpg)"></div>
					<div class="home_slider_content_container">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_slider_content"  data-animation-in="fadeIn" data-animation-out="animate-out fadeOut">

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>

			<!-- Home Slider Dots -->
			
			<div class="home_slider_dots_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="home_slider_dots">
								<ul id="home_slider_custom_dots" class="home_slider_custom_dots">
									<li class="home_slider_custom_dot active">*</li>
									<li class="home_slider_custom_dot">*</li>
									<li class="home_slider_custom_dot">*</li>
								</ul>
							</div>
						</div>
					</div>
				</div>	
			</div>

		</div>
	</div>

<!-- Newsletter -->

<div class="newsletter">
	<div class="container">
		<div class="row">
			<!--<div class="col">
				<div class="newsletter_border"></div>
			</div>-->
		</div>



		<div class="row steps">
			<div class="col-lg-8 offset-lg-2">
				<div class="newsletter_content text-center">
					<div class="newsletter_title">How To Apply ?</div>

					<div class="newsletter_text"><p class="num">1</p><p>Login or  Register If you are new to the website</p></div>
					<div class="newsletter_text"><p class="num">2</p><p>Look for the category of jobs you wish to apply for</p></div>
					<div class="newsletter_text"><p class="num">3</p><p>View relevant jobs</p></div>
					<div class="newsletter_text"><p class="num">4</p><p>Apply and wait for the confirmation</p></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


	<!-- Categories -->

	<div class="products">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_title">Job categories</div>
					<div class="product_grid">
					<?php
				$query = "SELECT * FROM jobs_category ORDER BY category_ID ASC";
				$resu = mysqli_query($db, $query);
				if(mysqli_num_rows($resu) > 0)
				{
					while($catg = mysqli_fetch_array($resu))
					{
				?>
						<!-- Product -->
						<div class="product">
							<div class="product_image"><img src="<?php echo $catg["category_image"]; ?>" alt="">
						
						</div>
						
							<div class="product_content">
								<div class="product_title"><a href="jobs.php"><?php echo $catg["category_name"]; ?></a></div>
			
							</div>
						</div>
						
						<?php
					}
				}
			?>
	
						<!-- Product -->
						<!-- <div class="product">
							<div class="product_image"><img src="images/product_3.jpg" alt=""></div>
							<div class="product_content">
								<div class="product_title"><a href="#">Development</a></div>
							</div>
						</div>		 -->				

						

					</div>
						
				</div>
			</div>
		</div>
	</div>

		<!-- Newsletter -->

		<div  class="newsletter">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="newsletter_border"></div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="newsletter_content text-center">
							<div class="newsletter_title">Know more about Job Portal</div>
							<div class="newsletter_form_container">
								<form target="_blank" action="#" id="newsletter_form" class="newsletter_form">
									<button class="newsletter_button trans_200"><span>Click here</span></button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


	

	<!-- Footer -->
	
	<div class="footer_overlay"></div>
	<footer class="footer">
		<div class="footer_background" style="background-image:url(images/footer.jpg)"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="footer_content d-flex flex-lg-row flex-column align-items-center justify-content-lg-start justify-content-center">
						<div class="footer_logo"><a href="#">JOB PORTAL</a></div>
						<div class="copyright ml-auto mr-auto"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved  
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="footer_social ml-lg-auto">
							<ul>
								<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>